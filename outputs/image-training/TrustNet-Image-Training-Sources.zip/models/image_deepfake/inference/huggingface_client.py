import os
from typing import Dict, Any, Optional
from dotenv import load_dotenv
import httpx
from huggingface_hub import HfApi

from models.image_deepfake.inference.local_vit_detector import LocalViTDeepfakeDetector

load_dotenv()

class HuggingFaceDeepfakeClient:
    """
    Hugging Face Deepfake Image Inference Client.
    Connects to pre-trained classification model on Hugging Face Hub:
    - Primary specialist: dima806/deepfake_vs_real_image_detection
    Seamlessly falls back to local transformers execution on HTTP 402/403/rate limits.
    """
    def __init__(
        self,
        api_key: Optional[str] = None,
        model_name: Optional[str] = None,
        face_model_name: Optional[str] = None,
        general_model_name: Optional[str] = None
    ):
        self.api_key = (api_key or os.getenv("HUGGINGFACE_API_KEY", "")).strip()
        self.face_model_name = (face_model_name or model_name or os.getenv("HF_DEEPFAKE_MODEL", "dima806/deepfake_vs_real_image_detection")).strip()
        self.model_name = self.face_model_name
        if general_model_name is not None:
            raise ValueError('Use a trained general_image CNN artifact; no second general ViT is implemented')
        self.general_model_name = None

        self.user_name: Optional[str] = None
        self._validate_token()
        self.local_detector = LocalViTDeepfakeDetector(
            face_model_name=self.face_model_name
        )

    def _validate_token(self):
        # Do not perform network I/O during construction or block startup on whoami.
        self.user_name = 'Configured HF account' if self.api_key.startswith('hf_') else None

    def is_configured(self) -> bool:
        if getattr(self, "_api_depleted", False):
            return False
        return os.getenv('IMAGE_ALLOW_HOSTED_INFERENCE', 'false').lower() == 'true' and bool(self.api_key and self.api_key.startswith('hf_'))

    def predict(self, image_bytes: bytes, has_face: bool = True, scene_type: str = "general_object") -> Dict[str, Any]:
        """
        Runs inference against Hugging Face deepfake detection model (dima806/deepfake_vs_real_image_detection).
        Falls back to local offline ViT when offline, rate-limited, or token depleted.
        """
        target_model = self.model_name

        is_face_only_model = any(k in target_model.lower() for k in ["face", "portrait", "deepfake_vs_real"])
        is_strictly_non_human = (not has_face) and (scene_type not in ["photograph_portrait"])
        if is_face_only_model and is_strictly_non_human and not self.general_model_name:
            return {
                "is_hf_applied": False,
                "hf_risk_score": 50.0,
                "hf_label": "unknown",
                "hf_confidence": 0.0,
                "model_name": target_model,
                "user": self.user_name,
                "note": f"Hugging Face ({target_model}) skipped: image does not contain a human face (scene: {scene_type}). Forensic evaluation routed to texture, micro-structure, and metadata engines."
            }

        if not self.is_configured():
            return self.local_detector.predict(image_bytes, has_face=has_face, scene_type=scene_type)

        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "image/png" if image_bytes.startswith(b"\x89PNG") else "image/jpeg"
        }

        endpoint_url = f"https://router.huggingface.co/hf-inference/models/{target_model}"

        try:
            with httpx.Client(timeout=10.0) as client:
                res = client.post(endpoint_url, headers=headers, content=image_bytes)

            if res.status_code == 200:
                data = res.json()
                from models.image_deepfake.inference.classifier_contract import parse_binary_predictions
                risk_score = parse_binary_predictions(data)
                confidence = 0.0
                label = 'fake' if risk_score >= 50 else 'real'

                return {
                    "is_hf_applied": True,
                    "hf_risk_score": risk_score,
                    "hf_label": label,
                    "hf_confidence": round(confidence, 2),
                    "model_name": target_model, "revision": None, "inference_mode": "hosted_unpinned",
                    "user": self.user_name,
                    "note": f"Hugging Face ({target_model}) fake score: {risk_score:.2f}/100. Scores are uncalibrated and do not verify camera origin."
                }

            if res.status_code in [402, 403]:
                self._api_depleted = True

            # If cloud returns 402/403 or rate-limits, execute local offline fallback
            local_res = self.local_detector.predict(image_bytes, has_face=has_face, scene_type=scene_type)
            if local_res.get("is_hf_applied"):
                local_res["user"] = self.user_name
                return local_res

            return {
                "is_hf_applied": False,
                "hf_risk_score": 50.0,
                "hf_label": "unknown",
                "hf_confidence": 0.0,
                "model_name": target_model,
                "note": f"Hugging Face HTTP {res.status_code}: {res.text[:100]}"
            }

        except Exception as e:
            local_res = self.local_detector.predict(image_bytes, has_face=has_face, scene_type=scene_type)
            if local_res.get("is_hf_applied"):
                local_res["user"] = self.user_name
                return local_res

            return {
                "is_hf_applied": False,
                "hf_risk_score": 50.0,
                "hf_label": "unknown",
                "hf_confidence": 0.0,
                "model_name": target_model,
                "note": f"Hugging Face inference error: {str(e)}"
            }
